def multiplication_table(number):
  for i in range(1,13):
    print(f"{number} x {i} = {number*i}")
number =5
multiplication_table(number)