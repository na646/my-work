def is_same_string(input_string, test_string):
  return input_string==test_string

input_string ="goodmorning"
test_string="goodmorning"
if is_same_string(input_string, test_string):
  print("the string are the same.")

else:
  print("the string are different.")